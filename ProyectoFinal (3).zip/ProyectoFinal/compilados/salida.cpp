#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

int num,contador;

int main() {
cout << "Ingresa un entero positivo" << endl;
cin >> num;
for(contador = 0; contador == num; contador++) {
cout << "Contandor vale " << contador << endl;
}
}
