#include "hashMap.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

// Función hash
unsigned int hash(char *nombre, char *ambito)
{
    char temp[MAX_CHAR];
    strcpy(temp, nombre);
    strcat(temp, ambito);
    int length = strlen(temp);
    unsigned int valor_hash = 0;
    for (int i = 0; i < length; i++)
        valor_hash += temp[i];
    return valor_hash % NUM_ELEMENTOS;
}

// Imprimir los contenidos de la tabla, tanto vacíos como utilizados
void imprimir_tabla()
{
    printf("\nIDENTIFICADOR\t|\tTIPO\t|\tFILA DE DECLARACION\t|\tAMBITO\t\t|\tFILAS DE USO\n");
    printf("------------------------------------------------------------------------------------------------------------------\n");
    for (int i = 0; i < NUM_ELEMENTOS; i++)
    {
        if (tabla_hash[i])
        {
            identificador *temp = tabla_hash[i];
            while (temp != NULL)
            {
                printf("%s\t\t\t%s\t\t\t%d\t\t\t%s\t\t\t", temp->nombre, temp->tipo, temp->fila_de_declaracion, temp->ambito);
                for (int i = 0; i < temp->ubicacion; i++)
                    printf("%d, ", temp->filas_de_uso[i]);
                printf("\n------------------------------------------------------------------------------------------------------------------\n");
                temp = temp->next;
            }
        }
    }
    printf("\n");
}

// Agregar a la tabla hash
void agregar(identificador *temp)
{
    if (temp == NULL)
        return;
    int indice = hash(temp->nombre, temp->ambito);
    identificador *nuevoNodo = malloc(sizeof(identificador));
    if (nuevoNodo)
    {
        memcpy(nuevoNodo, temp, sizeof(identificador));
        nuevoNodo->next = tabla_hash[indice];
        nuevoNodo->ubicacion = 0;
        tabla_hash[indice] = nuevoNodo;
    }
}

// Buscar elementos en la tabla hash por nombre del identificador
identificador *buscar(char *nombre, char *ambito)
{
    int indice = hash(nombre, ambito);
    identificador *temp = tabla_hash[indice];
    while (temp && strcmp(temp->nombre, nombre) != 0 && temp->ambito != ambito)
    {
        temp = temp->next;
    }
    return temp;
}
