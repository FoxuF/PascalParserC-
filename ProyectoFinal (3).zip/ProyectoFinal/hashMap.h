#pragma once

#pragma warning(disable : 4996 4013 4244 4267)

#define MAX_CHAR 127
#define NUM_ELEMENTOS 97 // Usar numero primo para reducir probabilidad de colision

typedef struct identificador identificador;
unsigned int hash(char *nombre, char *ambito);
void imprimir_tabla();
void agregar(identificador *temp);
identificador *buscar(char *nombre_identificador, char *ambito);
identificador *tabla_hash[NUM_ELEMENTOS];

// Tabla hash implementada como arreglo de listas (Chaining Hash Table)
struct identificador
{
    char *acumulador;
    char nombre[127];
    char tipo[10];
    int fila_de_declaracion;
    int filas_de_uso[NUM_ELEMENTOS];
    int ubicacion; // Seguimiento de cuantas veces se usa una variable para filas_de_uso
    char ambito[127];
    identificador *next;
};