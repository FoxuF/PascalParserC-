#pragma once
#pragma warning(disable : 4996 4013 4244 4267)

struct stack_entry {
  char *data;
  struct stack_entry *next;
};


struct stack_t
{
  struct stack_entry *head;
  size_t stackSize;
};

char *copyString(char *str);
void push(struct stack_t *theStack, char *value);
char *top(struct stack_t *theStack);
void pop(struct stack_t *theStack);
struct stack_t *newStack(void);
